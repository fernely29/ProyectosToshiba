/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actividad.ahd2;

import java.util.Scanner;

/**
 *
 * @author Telma Morales
 */
public class ActividadAHD2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        int opcion, subMenu1;
        do {
            System.out.println("Bienvenidos a las Estructuras de Control");
            System.out.println("Elige una opcion");
            System.out.println("1. Estructura if");
            System.out.println("1. Estructura else if");
            System.out.println("3. Switch Case");
            System.out.println("4. For");
            System.out.println("5. While");
            System.out.println("6. Ciclo Do While");
            System.out.println("7. Salir");
            opcion = entrada.nextInt();
            switch (opcion) {
                case 1:
                    do {
                        System.out.println("Estructura If");
                        System.out.println("1. Ingresar una temperatura mayor a 25");
                        System.out.println("2. Verificar si el numero es mayor a 15");
                        System.out.println("3. Regresar al menu Principal");
                        subMenu1 = entrada.nextInt();
                        switch (subMenu1) {
                            case 1:
                                System.out.println("Ingrese una temperatura");
                                float temperatura = entrada.nextFloat();
                                if (temperatura > 25) {
                                    System.out.println("Puedes ir a la playa");
                                }
                                break;
                            case 2:
                                System.out.println("Ingrese un valor numerico");
                                int a = entrada.nextInt();
                                if (a > 15) {
                                    System.out.println("El valor ingresado es mayor a 15");
                                }
                                break;
                            default:
                                System.out.println("opcion incorrecta");
                                break;
                        }
                    } while (subMenu1 != 3);
                    break;
                case 2:
                    do {
                        System.out.println("Estructura If/Else");
                        System.out.println("1. Verificar su un numero es par o impar");
                        System.out.println("2. Verificar si un numero es negativo o positivo");
                        System.out.println("3. Regresar al menu principal");
                        subMenu1 = entrada.nextInt();
                        switch (subMenu1) {
                            case 1:
                                System.out.println("Par o Impar");
                                System.out.println("Ingrese un numero");
                                int valor = entrada.nextInt();
                                if (valor % 2 == 0) {
                                    System.out.println("El numero es par");
                                } else {
                                    System.out.println("El numero es impar");
                                }
                                break;
                            case 2:
                                System.out.println("Positivo o Negativo");
                                System.out.println("Ingrese un numero");
                                int b = entrada.nextInt();
                                if (b > 0) {
                                    System.out.println("Es positivo");
                                } else {
                                    System.out.println("Es negativo");
                                }
                                break;
                            default:
                                System.out.println("Opcion incorrecta");
                                break;
                        }
                    } while (subMenu1 != 3);
                    break;
                case 3:
                    do {
                        double valor1,
                                valor2;
                        System.out.println("Estructura Switch Case");
                        System.out.println("Operaciones Básicas Aritmeticas");
                        System.out.println("Elije una opcion para realizar la operacion");
                        System.out.println("1. Suma");
                        System.out.println("2. Resta");
                        System.out.println("3. Multiplicacion");
                        System.out.println("4. Division");
                        System.out.println("5. Regresar al menu Principal");
                        subMenu1 = entrada.nextInt();
                        switch (subMenu1) {
                            case 1:
                                System.out.println("Opcion Suma");
                                System.out.println("Ingrese un valor");
                                valor1 = entrada.nextInt();
                                System.out.println("Ingrese otro valor");
                                valor2 = entrada.nextInt();
                                System.out.println("El resultado de la operacion es: " + (valor1 + valor2));
                                break;
                            case 2:
                                System.out.println("Opcion Resta");
                                System.out.println("Ingrese un valor");
                                valor1 = entrada.nextInt();
                                System.out.println("Ingrese otro valor");
                                valor2 = entrada.nextInt();
                                System.out.println("El resultado de la operacion es: " + (valor1 - valor2));
                                break;
                            case 3:
                                System.out.println("Opcion Multiplicacion");
                                System.out.println("Ingrese un valor");
                                valor1 = entrada.nextInt();
                                System.out.println("Ingrese otro valor");
                                valor2 = entrada.nextInt();
                                System.out.println("El resultado de la operacion es: " + (valor1 * valor2));
                                break;
                            case 4:
                                System.out.println("Opcion Division");
                                System.out.println("Ingrese un valor");
                                valor1 = entrada.nextInt();
                                System.out.println("Ingrese otro valor");
                                valor2 = entrada.nextInt();
                                System.out.println("El resultado de la operacion es: " + (valor1 / valor2));
                                break;
                            default:
                                System.out.println("Opcion incorrecta");
                                break;
                        }
                    } while (subMenu1 != 5);
                    break;
                case 4:
                    do {
                        System.out.println("Estructura For");
                        System.out.println("1. Mostrar los nummero 1-10");
                        System.out.println("2. Mostrar los numero impares 1-10");
                        System.out.println("3. Regresar al menu princial");
                        subMenu1 = entrada.nextInt();
                        switch (subMenu1) {
                            case 1:
                                System.out.println("Numero 1-10");
                                for (int i = 1; i <= 10; i++) {
                                    System.out.println(i);
                                }
                                break;
                            case 2:
                                System.out.println("Numero impares 1-3");
                                for (int i = 1; i < 10; i += 2) {
                                    System.out.println(i);
                                }
                                break;
                            default:
                                System.out.println("opcion incorrecta");
                                break;
                        }
                    } while (subMenu1 != 3);
                    break;
                case 5:
                    do {
                        System.out.println("Estrucuta While");
                        System.out.println("1. Numero pares 1-10");
                        System.out.println("2. Numeros 1-100");
                        System.out.println("3. Regresar al menu principal");
                        subMenu1 = entrada.nextInt();
                        switch (subMenu1) {
                            case 1:
                                System.out.println("Numeros pares 1-10");
                                int contador = 2;
                                while (contador <= 10) {
                                    System.out.println(contador);
                                    contador += 2;
                                }
                                break;
                            case 2:
                                System.out.println("Numero 1-100");
                                int contador2 = 1;
                                while (contador2 <= 100) {
                                    System.out.println(contador2);
                                    contador2++;
                                }
                                break;
                            default:
                                System.out.println("Opcion incorrecta");
                                break;
                        }
                    } while (subMenu1 != 3);
                    break;
                case 6:
                    do {
                        System.out.println("Estructura Do While");
                        System.out.println("1. Tablas de Multiplicar");
                        System.out.println("2. Verificar cuandos digitos tiene un numero 1-999");
                        System.out.println("3. Regresar al menu principal");
                        subMenu1 = entrada.nextInt();
                        switch (subMenu1) {
                            case 1:
                                System.out.println("Ingrese el valor de la tabla que desee ver");
                                int tabla = entrada.nextInt();
                                int numero = 1;
                                do {
                                    System.out.println(tabla + "*" + numero + "=" + tabla * numero);
                                    numero++;
                                } while (numero <= 10);
                                break;
                            case 2:
                                System.out.println("Cuando digitos tiene un numero de 1-999");
                                int c;
                                do {
                                    System.out.print("Ingrese un valor entre 1 y 999 (0 finaliza):");
                                    c = entrada.nextInt();
                                    if (c >= 100) {
                                        System.out.println("Tiene 3 dígitos.");
                                    } else {
                                        if (c >= 10) {
                                            System.out.println("Tiene 2 dígitos.");
                                        } else {
                                            System.out.println("Tiene 1 dígito.");
                                        }
                                    }
                                } while (c != 0);
                                break;
                            default:
                                System.out.println("Opcion incorrecta");
                                break;
                        }
                    } while (subMenu1 != 3);
                case 7:
                    System.out.println("Gracias por utilizar mi programa");
                    break;
                default:
                    System.out.println("Opcion incorrecta");
                    break;
            }

        } while (opcion != 7);
    }

}
