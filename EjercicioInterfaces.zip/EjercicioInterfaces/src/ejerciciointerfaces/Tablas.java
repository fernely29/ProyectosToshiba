package ejerciciointerfaces;
public interface Tablas {
    public void mostrarTablas();
    public void mostrarAlumnos(int cantidad);
    
}
